import TripPlanner from '@/components/TripPlanner';

const Index = () => {
  return <TripPlanner />;
};

export default Index;
