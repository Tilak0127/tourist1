import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { MapPin, Calendar, ArrowRight, ArrowLeft, Plane, Train, Car } from 'lucide-react';
import heroImage from '@/assets/hero-travel.jpg';

interface TripData {
  currentCity: string;
  selectedStates: string[];
  selectedDistricts: string[];
  tripDays: number;
  step: number;
}

const indianStates = [
  'Andhra Pradesh', 'Arunachal Pradesh', 'Assam', 'Bihar', 'Chhattisgarh', 'Goa', 'Gujarat',
  'Haryana', 'Himachal Pradesh', 'Jharkhand', 'Karnataka', 'Kerala', 'Madhya Pradesh',
  'Maharashtra', 'Manipur', 'Meghalaya', 'Mizoram', 'Nagaland', 'Odisha', 'Punjab',
  'Rajasthan', 'Sikkim', 'Tamil Nadu', 'Telangana', 'Tripura', 'Uttar Pradesh',
  'Uttarakhand', 'West Bengal', 'Delhi', 'Jammu and Kashmir', 'Ladakh'
];

const stateDistricts: { [key: string]: string[] } = {
  'Maharashtra': ['Mumbai', 'Pune', 'Nagpur', 'Nashik', 'Aurangabad', 'Kolhapur', 'Thane', 'Solapur'],
  'Karnataka': ['Bangalore', 'Mysore', 'Mangalore', 'Hubli', 'Belgaum', 'Gulbarga', 'Shimoga', 'Davangere'],
  'Tamil Nadu': ['Chennai', 'Coimbatore', 'Madurai', 'Tiruchirappalli', 'Salem', 'Tirunelveli', 'Vellore', 'Erode'],
  'Kerala': ['Thiruvananthapuram', 'Kochi', 'Kozhikode', 'Thrissur', 'Kollam', 'Alappuzha', 'Palakkad', 'Kottayam'],
  'Rajasthan': ['Jaipur', 'Jodhpur', 'Udaipur', 'Kota', 'Bikaner', 'Ajmer', 'Alwar', 'Bharatpur'],
  'Gujarat': ['Ahmedabad', 'Surat', 'Vadodara', 'Rajkot', 'Bhavnagar', 'Jamnagar', 'Gandhinagar', 'Anand'],
  'Uttar Pradesh': ['Lucknow', 'Kanpur', 'Ghaziabad', 'Agra', 'Varanasi', 'Meerut', 'Allahabad', 'Bareilly'],
  'West Bengal': ['Kolkata', 'Howrah', 'Durgapur', 'Asansol', 'Siliguri', 'Malda', 'Bardhaman', 'Kharagpur'],
  'Punjab': ['Chandigarh', 'Ludhiana', 'Amritsar', 'Jalandhar', 'Patiala', 'Bathinda', 'Mohali', 'Firozpur'],
  'Haryana': ['Gurgaon', 'Faridabad', 'Panipat', 'Ambala', 'Yamunanagar', 'Rohtak', 'Hisar', 'Karnal'],
  'Madhya Pradesh': ['Bhopal', 'Indore', 'Jabalpur', 'Gwalior', 'Ujjain', 'Sagar', 'Dewas', 'Satna'],
  'Goa': ['North Goa', 'South Goa'],
  'Himachal Pradesh': ['Shimla', 'Manali', 'Dharamshala', 'Kullu', 'Solan', 'Mandi', 'Chamba', 'Kangra'],
  'Uttarakhand': ['Dehradun', 'Haridwar', 'Rishikesh', 'Nainital', 'Mussoorie', 'Roorkee', 'Haldwani', 'Rudrapur']
};

const indianCities = [
  'Mumbai', 'Delhi', 'Bangalore', 'Chennai', 'Kolkata', 'Hyderabad', 'Pune', 'Ahmedabad',
  'Jaipur', 'Surat', 'Lucknow', 'Kanpur', 'Nagpur', 'Indore', 'Thane', 'Bhopal',
  'Visakhapatnam', 'Pimpri-Chinchwad', 'Patna', 'Vadodara', 'Ghaziabad', 'Ludhiana',
  'Agra', 'Nashik', 'Faridabad', 'Meerut', 'Rajkot', 'Kalyan-Dombivali'
];

export default function TripPlanner() {
  const [tripData, setTripData] = useState<TripData>({
    currentCity: '',
    selectedStates: [],
    selectedDistricts: [],
    tripDays: 0,
    step: 0
  });

  const updateTripData = (field: keyof TripData, value: any) => {
    setTripData(prev => ({ ...prev, [field]: value }));
  };

  // Enhanced Step Navigation: Clean up districts if moving to step 3
  const nextStep = () => {
    if (tripData.step < 4) {
      let newStep = tripData.step + 1;
      let newSelectedDistricts = tripData.selectedDistricts;
      if (newStep === 3) {
        // Only keep districts from selected states
        newSelectedDistricts = tripData.selectedDistricts.filter(district =>
          tripData.selectedStates.some(state => stateDistricts[state]?.includes(district))
        );
      }
      setTripData(prev => ({
        ...prev,
        step: newStep,
        selectedDistricts: newSelectedDistricts
      }));
    }
  };

  const prevStep = () => {
    if (tripData.step > 0) {
      setTripData(prev => ({ ...prev, step: prev.step - 1 }));
    }
  };

  const getStepTitle = () => {
    switch (tripData.step) {
      case 0: return "Plan Your Perfect Indian Journey";
      case 1: return "Where are you starting from?";
      case 2: return "Which states would you like to explore?";
      case 3: return "Select districts to visit";
      case 4: return "How long is your trip?";
      default: return "Let's plan your trip";
    }
  };

  const StepIndicator = () => (
    <div className="flex items-center justify-center space-x-2 mb-8">
      {[0, 1, 2, 3, 4].map((step) => (
        <div key={step} className="flex items-center">
          <div 
            className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium transition-all duration-300 ${
              step <= tripData.step 
                ? 'bg-gradient-to-r from-primary to-secondary text-white shadow-card-glow' 
                : 'bg-muted text-muted-foreground'
            }`}
          >
            {step + 1}
          </div>
          {step < 4 && (
            <div 
              className={`w-8 h-1 mx-2 transition-colors duration-300 ${
                step < tripData.step ? 'bg-gradient-to-r from-primary to-secondary' : 'bg-muted'
              }`}
            />
          )}
        </div>
      ))}
    </div>
  );

  if (tripData.step === 0) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-background via-muted/30 to-background">
        <div className="relative min-h-screen flex items-center justify-center">
          {/* Hero Background */}
          <div 
            className="absolute inset-0 bg-cover bg-center bg-no-repeat opacity-10"
            style={{ backgroundImage: `url(${heroImage})` }}
          />
          
          <div className="relative z-10 text-center max-w-4xl mx-auto px-6">
            <div className="mb-8">
              <h1 className="text-6xl md:text-7xl font-bold bg-gradient-to-r from-primary via-secondary to-accent bg-clip-text text-transparent mb-6">
                Incredible India
              </h1>
              <h2 className="text-2xl md:text-3xl font-semibold text-foreground mb-4">
                Your Journey Starts Here
              </h2>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto leading-relaxed">
                Discover the magic of India with our intelligent trip planner. From the snow-capped Himalayas to Kerala's serene backwaters, 
                plan your perfect adventure with real-time pricing and personalized recommendations.
              </p>
            </div>

            <div className="w-64 h-64 flex flex-col gap-4 justify-center items-center mb-12 mx-auto">
              <Button 
                size="lg" 
                onClick={nextStep}
                className="bg-gradient-to-r from-primary to-secondary hover:from-primary/90 hover:to-secondary/90 text-white px-8 py-6 text-lg font-medium shadow-card-shadow hover:shadow-card-glow transition-all duration-300"
              >
                Start Planning Your Trip
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-3xl mx-auto">
              <div className="text-center">
                <div className="w-16 h-16 bg-gradient-to-r from-primary to-secondary rounded-full flex items-center justify-center mx-auto mb-4 shadow-card-shadow">
                  <MapPin className="h-8 w-8 text-white" />
                </div>
                <h3 className="font-semibold text-foreground mb-2">Smart Routing</h3>
                <p className="text-sm text-muted-foreground">Optimized travel routes across states and districts</p>
              </div>
              
              <div className="text-center">
                <div className="w-16 h-16 bg-gradient-to-r from-secondary to-accent rounded-full flex items-center justify-center mx-auto mb-4 shadow-card-shadow">
                  <Calendar className="h-8 w-8 text-white" />
                </div>
                <h3 className="font-semibold text-foreground mb-2">Real-time Pricing</h3>
                <p className="text-sm text-muted-foreground">Live fare updates for trains, flights, and buses</p>
              </div>
              
              <div className="text-center">
                <div className="w-16 h-16 bg-gradient-to-r from-accent to-primary rounded-full flex items-center justify-center mx-auto mb-4 shadow-card-shadow">
                  <Plane className="h-8 w-8 text-white" />
                </div>
                <h3 className="font-semibold text-foreground mb-2">Complete Booking</h3>
                <p className="text-sm text-muted-foreground">Hotels, transport, and activities all in one place</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-muted/20 to-background py-8 px-4">
      <div className="max-w-2xl mx-auto">
        <StepIndicator />
        
        <Card className="shadow-card-shadow border-0 bg-card/95 backdrop-blur-sm">
          <CardHeader className="text-center pb-6">
            <CardTitle className="text-2xl font-bold text-foreground">
              {getStepTitle()}
            </CardTitle>
            <CardDescription className="text-muted-foreground">
              Step {tripData.step} of 4
            </CardDescription>
          </CardHeader>
          
          <CardContent className="space-y-6">
            {/* Step 1: Current City */}
            {tripData.step === 1 && (
              <div className="space-y-4">
                <Label htmlFor="currentCity" className="text-sm font-medium text-foreground">
                  Select your current city
                </Label>
                <Select onValueChange={(value) => updateTripData('currentCity', value)}>
                  <SelectTrigger className="w-full bg-input border-border focus:ring-primary">
                    <SelectValue placeholder="Choose your starting city..." />
                  </SelectTrigger>
                  <SelectContent className="bg-popover border-border max-h-60">
                    {indianCities.map(city => (
                      <SelectItem key={city} value={city} className="hover:bg-muted">
                        {city}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {tripData.currentCity && (
                  <div className="p-4 bg-gradient-to-r from-primary/10 to-secondary/10 rounded-lg border border-primary/20">
                    <p className="text-sm text-muted-foreground">Starting your journey from</p>
                    <p className="font-semibold text-foreground flex items-center">
                      <MapPin className="h-4 w-4 mr-2 text-primary" />
                      {tripData.currentCity}
                    </p>
                  </div>
                )}
              </div>
            )}

            {/* Step 2: State Selection */}
            {tripData.step === 2 && (
              <div className="space-y-4">
                <Label className="text-sm font-medium text-foreground">
                  Which states would you like to explore?
                </Label>
                <div className="grid grid-cols-2 gap-3 max-h-60 overflow-y-auto">
                  {indianStates.map(state => (
                    <div key={state} className="flex items-center space-x-2">
                      <input
                        type="checkbox"
                        id={state}
                        className="rounded border-border text-primary focus:ring-primary"
                        checked={tripData.selectedStates.includes(state)}
                        onChange={(e) => {
                          if (e.target.checked) {
                            updateTripData('selectedStates', [...tripData.selectedStates, state]);
                          } else {
                            // Remove state and its districts from selected lists
                            const filteredStates = tripData.selectedStates.filter(s => s !== state);
                            const filteredDistricts = tripData.selectedDistricts.filter(district =>
                              filteredStates.some(selectedState => stateDistricts[selectedState]?.includes(district))
                            );
                            setTripData(prev => ({
                              ...prev,
                              selectedStates: filteredStates,
                              selectedDistricts: filteredDistricts
                            }));
                          }
                        }}
                      />
                      <label htmlFor={state} className="text-sm text-foreground cursor-pointer">
                        {state}
                      </label>
                    </div>
                  ))}
                </div>
                {tripData.selectedStates.length > 0 && (
                  <div className="flex flex-wrap gap-2 pt-4">
                    {tripData.selectedStates.map(state => (
                      <Badge key={state} variant="secondary" className="bg-gradient-to-r from-primary/20 to-secondary/20 text-foreground">
                        {state}
                      </Badge>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* Step 3: District Selection */}
            {tripData.step === 3 && (
              <div className="space-y-4">
                <Label className="text-sm font-medium text-foreground">
                  Select specific districts to visit
                </Label>
                {tripData.selectedStates.map(state => (
                  stateDistricts[state] && (
                    <div key={state} className="space-y-2">
                      <h4 className="font-medium text-foreground">{state}</h4>
                      <div className="grid grid-cols-2 gap-2">
                        {stateDistricts[state].map(district => {
                          const uniqueId = `${state}-${district}`;
                          return (
                            <div key={uniqueId} className="flex items-center space-x-2">
                              <input
                                type="checkbox"
                                id={uniqueId}
                                checked={tripData.selectedDistricts.includes(district)}
                                onChange={(e) => {
                                  if (e.target.checked) {
                                    updateTripData('selectedDistricts', [...tripData.selectedDistricts, district]);
                                  } else {
                                    updateTripData('selectedDistricts', tripData.selectedDistricts.filter(d => d !== district));
                                  }
                                }}
                                className="rounded border-border text-primary focus:ring-primary"
                              />
                              <label htmlFor={uniqueId} className="text-sm text-foreground cursor-pointer">
                                {district}
                              </label>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  )
                ))}
              </div>
            )}

            {/* Step 4: Trip Duration */}
            {tripData.step === 4 && (
              <div className="space-y-6">
                <div className="space-y-4">
                  <Label htmlFor="tripDays" className="text-sm font-medium text-foreground">
                    How many days are you planning to travel?
                  </Label>
                  <Input
                    id="tripDays"
                    type="number"
                    min="1"
                    max="30"
                    placeholder="Enter number of days"
                    className="bg-input border-border focus:ring-primary"
                    onChange={(e) => updateTripData('tripDays', parseInt(e.target.value))}
                  />
                </div>

                {tripData.tripDays > 0 && (
                  <div className="space-y-4 p-6 bg-gradient-to-r from-primary/5 to-secondary/5 rounded-lg border border-primary/20">
                    <h3 className="text-lg font-semibold text-foreground mb-4">Trip Summary</h3>
                    
                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-muted-foreground">From:</span>
                        <span className="font-medium text-foreground">{tripData.currentCity}</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-muted-foreground">Exploring:</span>
                        <span className="font-medium text-foreground">{tripData.selectedStates.length} states</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-muted-foreground">Duration:</span>
                        <span className="font-medium text-foreground">{tripData.tripDays} days</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-muted-foreground">Districts:</span>
                        <span className="font-medium text-foreground">{tripData.selectedDistricts.length} selected</span>
                      </div>
                    </div>

                    <div className="grid grid-cols-3 gap-4 pt-4 border-t border-border/50">
                      <div className="text-center">
                        <Train className="h-8 w-8 mx-auto mb-2 text-primary" />
                        <p className="text-xs text-muted-foreground">Rail</p>
                        <p className="font-semibold text-foreground">₹2,450</p>
                      </div>
                      <div className="text-center">
                        <Plane className="h-8 w-8 mx-auto mb-2 text-secondary" />
                        <p className="text-xs text-muted-foreground">Flight</p>
                        <p className="font-semibold text-foreground">₹8,900</p>
                      </div>
                      <div className="text-center">
                        <Car className="h-8 w-8 mx-auto mb-2 text-accent" />
                        <p className="text-xs text-muted-foreground">Bus</p>
                        <p className="font-semibold text-foreground">₹1,200</p>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Navigation Buttons */}
            <div className="flex justify-between pt-6 border-t border-border/50">
              <Button
                variant="outline"
                onClick={prevStep}
                disabled={tripData.step === 1}
                className="border-border hover:bg-muted"
              >
                <ArrowLeft className="mr-2 h-4 w-4" />
                Previous
              </Button>
              
              <Button
                onClick={nextStep}
                disabled={
                  (tripData.step === 1 && !tripData.currentCity) ||
                  (tripData.step === 2 && tripData.selectedStates.length === 0) ||
                  (tripData.step === 3 && tripData.selectedDistricts.length === 0) ||
                  (tripData.step === 4 && tripData.tripDays <= 0)
                }
                className="bg-gradient-to-r from-primary to-secondary hover:from-primary/90 hover:to-secondary/90 text-white shadow-card-shadow hover:shadow-card-glow transition-all duration-300"
              >
                {tripData.step === 4 ? 'Complete Trip Plan' : 'Continue'}
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}