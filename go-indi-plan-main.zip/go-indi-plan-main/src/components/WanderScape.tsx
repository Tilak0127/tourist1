import React, { useState } from "react";
import LandingPage from "./LandingPage";
import TripTypeSelection from "./TripTypeSelection";
// Future imports for further steps (OriginDetails, StateSelection, etc.)

const steps = [
  "landing",
  "triptype"
  // To be expanded: "origin", "state", "city", "places", "recommendations", "stay", "summary"
];

export default function WanderScape() {
  const [step, setStep] = useState(0);
  const [tripData, setTripData] = useState({
    tripType: null,
    // Add more fields as steps expand
  });

  const goNext = () => setStep(s => Math.min(steps.length - 1, s + 1));
  const goBack = () => setStep(s => Math.max(0, s - 1));
  const updateTripData = (data: any) => setTripData(prev => ({ ...prev, ...data }));

  switch (steps[step]) {
    case "landing":
      return <LandingPage onStart={goNext} />;
    case "triptype":
      return <TripTypeSelection
        onSelect={type => { updateTripData({ tripType: type }); goNext(); }}
        onBack={goBack}
      />;
    default:
      return null;
  }
}