import React from 'react';

export default function LandingPage({ onStart }: { onStart: () => void }) {
  return (
    <div className="min-h-screen flex flex-col justify-center items-center bg-gradient-to-br from-blue-200 via-pink-100 to-yellow-50 relative">
      <img
        src="/images/branding/hero.jpg"
        alt="The Magic of Trip Planning"
        className="absolute inset-0 object-cover w-full h-full opacity-40 pointer-events-none"
      />
      <div className="relative z-10 flex flex-col items-center p-8 rounded-xl bg-white/80 backdrop-blur-sm shadow-2xl">
        <h1 className="text-5xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-indigo-500 via-pink-500 to-yellow-500 mb-4">
          WanderScape
        </h1>
        <p className="text-lg md:text-xl text-gray-800 mb-8 font-medium">
          Discover, Plan, Explore Your Next Indian Adventure!
        </p>
        <button
          className="px-8 py-4 rounded-full bg-gradient-to-r from-pink-500 to-indigo-500 text-white text-xl font-semibold shadow-lg hover:scale-105 transition"
          onClick={onStart}
        >
          Plan a Trip
        </button>
      </div>
    </div>
  );
}